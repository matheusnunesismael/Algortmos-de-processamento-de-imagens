# LZW Image Compressor

Algoritmo para compactar imagens em formato LZW 

## Diretivas

**-i** diretiva que precede o nome do arquivo de entrada

**-o** diretiva que precede o nome do arquivo de saida

**-e** diretiva informada independentemente que codifica a imagem de entrada para formato LZW

**-d** diretiva informada independentemente que decodifica o arquivo de entrada do formato LZW para o formato especificado no nome do arquivo de saída
